/**
 * Artzy Studio Storefront Worker
 * Deployed separately from ERP worker.
 * Handles: SPA routing, sitemap, robots.txt, enquiry proxy, slug API.
 *
 * Deploy: wrangler deploy --name artzy-storefront
 * Bindings: ARTZY_ERP (Service binding to erp worker) OR use fetch()
 */

const ERP = "https://erp.artzysstudio.in";
const WA_NUMBER = "919999999999"; // Update before launch

// ── CORS headers for cross-origin API calls ──────────────────────────────────
const CORS = {
  "Access-Control-Allow-Origin":  "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS, ...extra },
  });
}

function err(msg, status = 400) {
  return json({ success: false, error: msg }, status);
}

// ── Cloudflare Cache API helper ──────────────────────────────────────────────
async function cachedFetch(url, ttl = 300) {
  const cacheKey = new Request(url);
  const cache    = caches.default;
  let cached     = await cache.match(cacheKey);
  if (cached) return cached;

  const res = await fetch(url).catch(() => null);
  if (!res?.ok) return null;

  const clone = res.clone();
  const resWithCache = new Response(clone.body, {
    ...res,
    headers: {
      ...Object.fromEntries(res.headers),
      "Cache-Control": `public, max-age=${ttl}`,
    },
  });
  await cache.put(cacheKey, resWithCache.clone());
  return resWithCache;
}

// ── Routes ───────────────────────────────────────────────────────────────────
export default {
  async fetch(request, env, ctx) {
    const url    = new URL(request.url);
    const path   = url.pathname;
    const method = request.method;

    // CORS preflight
    if (method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    // ── Sitemap ──────────────────────────────────────────────────────────────
    if (path === "/sitemap.xml") return handleSitemap(url);

    // ── Robots ───────────────────────────────────────────────────────────────
    if (path === "/robots.txt") return handleRobots(url);

    // ── Manifest ─────────────────────────────────────────────────────────────
    if (path === "/manifest.json") return handleManifest();

    // ── Single artwork by slug ────────────────────────────────────────────────
    if (path.startsWith("/api/artworks/") && method === "GET") {
      const slug = path.slice("/api/artworks/".length).replace(/\/$/, "");
      return handleArtworkBySlug(slug);
    }

    // ── Enquiry submit (proxied from storefront to ERP) ───────────────────────
    if (path === "/api/enquiry" && method === "POST") {
      return handleEnquiry(request);
    }

    // ── Newsletter signup ─────────────────────────────────────────────────────
    if (path === "/api/newsletter" && method === "POST") {
      return handleNewsletter(request);
    }

    // ── Muse chat proxy ───────────────────────────────────────────────────────
    if (path === "/api/muse" && method === "POST") {
      return handleMuse(request);
    }

    // ── Static assets / SPA fallback handled by Cloudflare Pages ────────────
    // This worker only handles API routes above.
    return new Response("Not found", { status: 404 });
  },
};

// ── Artwork by slug ───────────────────────────────────────────────────────────
async function handleArtworkBySlug(slug) {
  if (!slug) return err("slug required");

  // 1. Try ERP single-slug endpoint (if added later)
  // 2. Fall back to fetching all published and filtering by slug (current ERP)
  const r = await cachedFetch(
    `${ERP}/api/sync/artworks?limit=500`, 180
  );
  if (!r) return err("ERP unavailable", 503);
  const data = await r.json();
  const artwork = (data.data || []).find(a => a.slug === slug);
  if (!artwork) return json({ success: false, error: "Not found" }, 404);
  return json({ success: true, data: artwork });
}

// ── Enquiry proxy ─────────────────────────────────────────────────────────────
async function handleEnquiry(request) {
  let body;
  try { body = await request.json(); }
  catch { return err("Invalid JSON"); }

  const { name, email, mobile, message, artwork_id, artwork_title, source = "storefront" } = body;
  if (!name || !email) return err("name and email are required");
  if (!message)        return err("message is required");

  const payload = {
    name, email, phone: mobile || "",
    message: artwork_title
      ? `Re: "${artwork_title}"\n\n${message}`
      : message,
    source,
    status: "new",
    artwork_id: artwork_id || null,
  };

  // Forward to ERP CRM enquiries endpoint
  const res = await fetch(`${ERP}/api/crm/enquiries/public`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(payload),
  }).catch(() => null);

  if (!res?.ok) {
    // Log but don't fail the user — store fallback note
    console.error("ERP enquiry forward failed", res?.status);
    return json({ success: true, fallback: true,
      message: "Enquiry received. We'll contact you soon." });
  }

  return json({ success: true, message: "Thank you! We'll be in touch within 24 hours." });
}

// ── Newsletter ─────────────────────────────────────────────────────────────────
async function handleNewsletter(request) {
  let body;
  try { body = await request.json(); }
  catch { return err("Invalid JSON"); }

  const { email, name } = body;
  if (!email) return err("email required");

  await fetch(`${ERP}/api/crm/customers`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ email, name: name || email, source: "newsletter_storefront" }),
  }).catch(() => {});

  return json({ success: true, message: "You're subscribed. Thank you!" });
}

// ── Muse chat proxy ────────────────────────────────────────────────────────────
async function handleMuse(request) {
  let body;
  try { body = await request.json(); }
  catch { return err("Invalid JSON"); }

  const res = await fetch(`${ERP}/api/muse/chat`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ ...body, source: "storefront" }),
  }).catch(() => null);

  if (!res?.ok) {
    return json({
      success: true,
      reply: "Artzy Muse is warming up. Browse our collection or WhatsApp us for personal assistance.",
    });
  }
  return res;
}

// ── Sitemap ────────────────────────────────────────────────────────────────────
async function handleSitemap(baseUrl) {
  const base = `https://www.artzysstudio.in`;
  const now  = new Date().toISOString().split("T")[0];

  // Fetch all published artworks for individual URLs
  const r = await cachedFetch(`${ERP}/api/sync/artworks?limit=500`, 3600).catch(() => null);
  const artworks = r ? (await r.json().catch(() => ({}))).data || [] : [];

  // Fetch categories
  const rc = await cachedFetch(`${ERP}/api/sync/categories`, 3600).catch(() => null);
  const categories = rc ? (await rc.json().catch(() => ({}))).data?.categories || [] : [];

  const staticPages = [
    { url: "/",           priority: "1.0", freq: "daily"   },
    { url: "/artworks",   priority: "0.9", freq: "daily"   },
    { url: "/shop",       priority: "0.9", freq: "daily"   },
    { url: "/collections",priority: "0.8", freq: "weekly"  },
    { url: "/about",      priority: "0.6", freq: "monthly" },
    { url: "/contact",    priority: "0.6", freq: "monthly" },
  ];

  const catPages = categories.map(c => ({
    url:      `/shop?category=${c.slug}`,
    priority: "0.7",
    freq:     "weekly",
    date:     now,
  }));

  const artworkPages = artworks.map(a => ({
    url:      `/artworks/${a.slug}`,
    priority: a.featured ? "0.85" : "0.75",
    freq:     "weekly",
    date:     (a.updated_at || now).split("T")[0],
  }));

  const allPages = [...staticPages, ...catPages, ...artworkPages];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allPages.map(p => `  <url>
    <loc>${base}${p.url}</loc>
    ${p.date ? `<lastmod>${p.date}</lastmod>` : `<lastmod>${now}</lastmod>`}
    <changefreq>${p.freq || "weekly"}</changefreq>
    <priority>${p.priority || "0.5"}</priority>
  </url>`).join("\n")}
</urlset>`;

  return new Response(xml, {
    headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
  });
}

// ── Robots ────────────────────────────────────────────────────────────────────
function handleRobots(baseUrl) {
  const robots = `User-agent: *
Allow: /
Disallow: /wishlist
Disallow: /cart
Disallow: /api/

Sitemap: https://www.artzysstudio.in/sitemap.xml

# Crawl-delay for polite bots
Crawl-delay: 5`;

  return new Response(robots, {
    headers: { "Content-Type": "text/plain", "Cache-Control": "public, max-age=86400" },
  });
}

// ── Manifest ──────────────────────────────────────────────────────────────────
function handleManifest() {
  return new Response(JSON.stringify({
    name:             "Artzy's Studio",
    short_name:       "Artzy's",
    description:      "Original Indian art and handcrafted décor",
    start_url:        "/",
    display:          "standalone",
    background_color: "#F8F4F2",
    theme_color:      "#A64C57",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  }, null, 2), {
    headers: { "Content-Type": "application/manifest+json", "Cache-Control": "public, max-age=86400" },
  });
}
